package br.unipar.devbackend.atividade1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atividade1ApplicationTests {

    @Test
    void contextLoads() {
    }

}
